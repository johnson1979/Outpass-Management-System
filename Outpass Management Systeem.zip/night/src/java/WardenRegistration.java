import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class WardenRegistration extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String dob = request.getParameter("dob");
        String branch = request.getParameter("branch");
        String block = request.getParameter("block");
        String email = request.getParameter("email");
        String  password= request.getParameter("password");
         
        
     
       
      
      if(!ValidateWarden.checkId(id))
        {
    try{
             
                Class.forName("com.mysql.jdbc.Driver");
               
                  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
                
                   
               PreparedStatement ps = con.prepareStatement("insert into warden_info values(?,?,?,?,?,?,?)");
                
                ps.setString(1,id);
                
                ps.setString(2,name);
               
                ps.setString(3,dob);
                 
                ps.setString(4,branch);
                ps.setString(5,block);
                ps.setString(6,email);
                ps.setString(7,password);
                
                  
                int i = 0;
                i=ps.executeUpdate();
                
      
                  if(i>0)
                    {
                       RequestDispatcher rs = request.getRequestDispatcher("submission_success_warden.html");
                        rs.include(request, response);
                        con.close();
                     }
        }
                        
      catch(Exception e)
                            {
                             out.println(e);
                             }
       
    }
        else if(id==null )
        {
            if(id=="")
            {
            out.print("please enter the id/name first");
             RequestDispatcher rs = request.getRequestDispatcher("warden_register.html");
                        rs.include(request, response);  
            }
        }
        else{
            out.print("you are already registered with the id "+id);
             RequestDispatcher rs = request.getRequestDispatcher("warden_register.html");
                        rs.include(request, response);
                        
        }
}   }     
            
