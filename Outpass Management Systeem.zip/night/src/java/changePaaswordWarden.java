import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.*;

/**
 *
 * @author johnson
 */
public class changePaaswordWarden extends HttpServlet {

   RequestDispatcher rd;
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String id = request.getParameter("id");
        String mail = request.getParameter("mail");
      
       
        
        if(ValidationWarden.checkUser(id,mail))
        {     
            
             rd = request.getRequestDispatcher("changePasswordWarden.html");
             rd.include(request, response);
             
              HttpSession session = request.getSession();
                session.setAttribute("id",id);
            
        }
        else
        {
            out.println("else case ");
            out.println("Your Id and corresponding Mail is not matching");
            rd = request.getRequestDispatcher("forgotpassWarden.html");
            rd.include(request, response);
        }
    }
}
