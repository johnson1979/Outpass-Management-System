import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author johnson
 */
public class SendNote extends HttpServlet {

  
  


  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String about=request.getParameter("about");
        String note=request.getParameter("note");
         try{
             
                Class.forName("com.mysql.jdbc.Driver");
               
                  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
            PreparedStatement ps = con.prepareStatement("insert into notifications values(?,?)");
            ps.setString(1,about);
            ps.setString(2, note);
            int i=ps.executeUpdate();
            if(i!=0)
            {
                 RequestDispatcher rs = request.getRequestDispatcher("warden_mainPage.html");
                        rs.include(request, response);
                        con.close();
                out.print("notifications sent!");
            }
            
            
            
         }catch(Exception e)
         {
         }
             
       
    }

  

}
