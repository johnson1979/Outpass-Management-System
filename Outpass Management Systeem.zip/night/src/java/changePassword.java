import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.*;

/**
 *
 * @author johnson
 */
public class changePassword extends HttpServlet {

   RequestDispatcher rd;
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String id = request.getParameter("id");
        String mail = request.getParameter("mail");
      
       
        
        if(Validation.checkUser(id,mail))
        {     
            
             rd = request.getRequestDispatcher("changePassword.html");
             rd.include(request, response);
             
              HttpSession session = request.getSession();
                session.setAttribute("id",id);
            
        }
         else  if(ValidationWarden.checkUser(id,mail))
        {
            
            rd = request.getRequestDispatcher("changePasswordWarden.html");
            rd.include(request, response);
            
             HttpSession session = request.getSession();
                session.setAttribute("id",id);
            
        }
        else
        {
            
            out.println("Your Id and corresponding Mail is not matching..!");
            rd = request.getRequestDispatcher("forgotpass.html");
            rd.include(request, response);
        }
    }
}
