import java.sql.*;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;


public class Validation
{
   
    public static boolean checkUser(String id,String mail)
    {
            HttpServletResponse response;
            
        
        boolean st = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
            PreparedStatement ps = con.prepareStatement("select * from registration where  id=? and email=?");
            
            ps.setString(1,id);
            ps.setString(2, mail);
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
}