/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import demo.checkStudent;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


/**
 *
 * @author johnson
 */
public class submitToWarden extends HttpServlet {

  


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        /**String name = request.getParameter("name");
        String department  = request.getParameter("department");
        String yearsem = request.getParameter("yearsem");
        **/
        HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");
        RequestDispatcher rs;
          
        String hostel = request.getParameter("hostelroom");
        String dol = request.getParameter("dateofleave");
        String  dor= request.getParameter("dateofreturn");
        String  cno= request.getParameter("cnumber");
        String  address= request.getParameter("address");
        String reason = request.getParameter("reason");
        response.setContentType("text/html");
          PreparedStatement ps=null;
         Connection con=null;
         PrintWriter out=response.getWriter();
         int i=0;
         String status="0";
           checkStudent.checkBranch(id);
                   
          String branch=checkStudent.getBranch();
          
          if(branch.equals("cse")||branch.equals("CSE"))
          {
               try{
               Class.forName("com.mysql.jdbc.Driver");
               
                  
               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");}
              catch(Exception e)
              {
                  out.print(e);
              }
          if(cse.checkId(id))
          {
             
              try{
                  
              ps= con.prepareStatement("update cse set hostel=('"+hostel+"'), dol=('"+dol+"'), dor=('"+dor+"'), cno=('"+cno+"'), address=('"+address+"'), reason=('"+reason+"'), status=('"+status+"') where id=('"+id+"')");
              ps.executeUpdate();  
              rs = request.getRequestDispatcher("outpass_accepted.html");
                        rs.include(request, response);
              }
          catch(Exception e)
          {
                out.print(e);
          }
          }
          else{
              try{
              
              ps = con.prepareStatement("insert into cse values(?,?,?,?,?,?,?,?)");
              
                ps.setString(1,id);
                ps.setString(2,hostel);
                ps.setString(3,dol);
                ps.setString(4,dor);
                ps.setString(5,cno);
                ps.setString(6,address);
                ps.setString(7,reason);
                ps.setString(8,status);
                
                
                
                i = ps.executeUpdate();
                
               
                  if(i!=0)
                    {
                       rs = request.getRequestDispatcher("outpass_accepted.html");
                        rs.include(request, response);
                        
                     }
          }catch(Exception e)
          {
              out.print(e);
          }
          }
          }
           else if(branch.equals("ece")||branch.equals("ECE"))
          {
              try{
               Class.forName("com.mysql.jdbc.Driver");
               
                  
               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");}
              catch(Exception e)
              {
                  out.print(e);
              }
          if(ece.checkId(id))
          {
              try{
              ps= con.prepareStatement("update ece set hostel=('"+hostel+"'), dol=('"+dol+"'), dor=('"+dor+"'), cno=('"+cno+"'), address=('"+address+"'), reason=('"+reason+"'), status=('"+status+"') where id=('"+id+"')");
         ps.executeUpdate();
              rs = request.getRequestDispatcher("outpass_accepted.html");
                        rs.include(request, response);
              }
          catch(Exception e)
          {
                out.print(e);
          }
          }
            else{
              try{
              ps = con.prepareStatement("insert into ece values(?,?,?,?,?,?,?,?)");
              
                ps.setString(1,id);
                ps.setString(2,hostel);
                ps.setString(3,dol);
                ps.setString(4,dor);
                ps.setString(5,cno);
                ps.setString(6,address);
                ps.setString(7,reason);
                ps.setString(8,status);
                
                
                
                i = ps.executeUpdate();
                
               
                  if(i!=0)
                    {
                       rs = request.getRequestDispatcher("outpass_accepted.html");
                        rs.include(request, response);
                        
                     }
          }catch(Exception e)
          {
              out.print(e);
          }
          }
          
          }
            else if(branch.equals("mech")||branch.equals("MECH"))
          {
              try{
               Class.forName("com.mysql.jdbc.Driver");
               
                  
               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");}
              catch(Exception e)
              {
                  out.print(e);
              }
          if(mech.checkId(id))
          {
             try{
              ps= con.prepareStatement("update mech set hostel=('"+hostel+"'), dol=('"+dol+"'), dor=('"+dor+"'), cno=('"+cno+"'), address=('"+address+"'), reason=('"+reason+"'), status=('"+status+"') where id=('"+id+"')");
              ps.executeUpdate();
              rs = request.getRequestDispatcher("outpass_accepted.html");
                        rs.include(request, response);
             }
          catch(Exception e)
          {
                out.print(e);
          }
          }
            else{
              try{
              ps = con.prepareStatement("insert into mech values(?,?,?,?,?,?,?,?)");
              
                ps.setString(1,id);
                ps.setString(2,hostel);
                ps.setString(3,dol);
                ps.setString(4,dor);
                ps.setString(5,cno);
                ps.setString(6,address);
                ps.setString(7,reason);
                ps.setString(8,status);
                
                
                
                i = ps.executeUpdate();
                
               
                  if(i!=0)
                    {
                       rs = request.getRequestDispatcher("outpass_accepted.html");
                        rs.include(request, response);
                        
                     }
          }catch(Exception e)
          {
              out.print(e);
          }
          }
          }
          
          
          
         /** else{
          out.print(id);
          try{
                
               
                 switch(branch)
                {
                    case "cse" :
                        
                    ps = con.prepareStatement("insert into cse values(?,?,?,?,?,?,?,?)");
                    break;
                     case "CSE" :
                        
                    ps = con.prepareStatement("insert into cse values(?,?,?,?,?,?,?,?)");
                    break;
                    case "ece":
                       
                    ps = con.prepareStatement("insert into ece values(?,?,?,?,?,?,?,?)");
                    break;
                        case "ECE":
                       
                    ps = con.prepareStatement("insert into ece values(?,?,?,?,?,?,?,?)");
                    break;
                    case "mech":
                    ps = con.prepareStatement("insert into mech values(?,?,?,?,?,?,?,?)");
                    break;
                         case "MECH":
                    ps = con.prepareStatement("insert into mech values(?,?,?,?,?,?,?,?)");
                    break;
                    default:
                        
                        rs = request.getRequestDispatcher("outpass_form.html");
            rs.include(request, response);
                    break;
                           
                }
                
                   
               
                
               
                 
                ps.setString(1,id);
                ps.setString(2,hostel);
                ps.setString(3,dol);
                ps.setString(4,dor);
                ps.setString(5,cno);
                ps.setString(6,address);
                ps.setString(7,reason);
                ps.setString(8,status);
                
                
                
                i = ps.executeUpdate();
                
               
                  if(i!=0)
                    {
                       rs = request.getRequestDispatcher("outpass_accepted.html");
                        rs.include(request, response);
                        con.close();
                     }
        }
                        
      catch(Exception e)
                            {
                             out.println(e);
                             }
          }**/
       
       
    }

 
}
