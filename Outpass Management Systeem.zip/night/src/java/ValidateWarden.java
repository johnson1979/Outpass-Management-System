import java.sql.*;
public class ValidateWarden
{
    public static boolean checkUser(String id,String password)
    {
        boolean st = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
            PreparedStatement ps = con.prepareStatement("select * from warden_info where  id=? and password=?");
            ps.setString(1,id);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
    public static boolean checkId(String id)
    {
        boolean st = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
            PreparedStatement ps = con.prepareStatement("select * from warden_info where  id=?");
            ps.setString(1,id);
            
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
}