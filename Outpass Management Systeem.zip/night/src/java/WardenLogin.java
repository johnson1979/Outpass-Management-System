import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.*;

/**
 *
 * @author teja
 */
public class WardenLogin extends HttpServlet {

   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
            RequestDispatcher rs;
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String id = request.getParameter("id");
        String password = request.getParameter("password");
        if(ValidateWarden.checkUser(id,password))
        {
            
            rs = request.getRequestDispatcher("warden_mainPage.html");
            rs.include(request, response);
            
             HttpSession session = request.getSession();
                session.setAttribute("id",id);
            
        }
        else
        {
            out.println("Username or Password incorrect");
            rs = request.getRequestDispatcher("warden_login.html");
            rs.include(request, response);
        }
    }
}
