import demo.CheckWarden;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;


/**
 *
 * @author johnson
 */
public class Approve extends HttpServlet {



    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
            response.setContentType("text/html");
        PrintWriter out = response.getWriter();
       
         String students[]= request.getParameterValues("student");
        int status=1;
         PreparedStatement ps=null;
        
                
        try{
              HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
              CheckWarden.checkBranch(id);
                   
          String branch=CheckWarden.getBranch();
           
            for(String student: students)
            {
                if(branch.equals("cse")||branch.equals("CSE"))
                {
               
                     ps= con.prepareStatement("update cse set status=('"+status+"') where id=('"+student+"')");
                }
                else if(branch.equals("ece")||branch.equals("ECE"))
                {
                    ps= con.prepareStatement("update ece set status=('"+status+"') where id=('"+student+"')");
                }
                 else if(branch.equals("mech")||branch.equals("MECH"))
                {
                    ps= con.prepareStatement("update mech set status=('"+status+"') where id=('"+student+"')");
                }
                 else{
                        out.print("you dont have the permission to approve!");
                 }
                
                int i = ps.executeUpdate();
                    
                
                }
            out.println("<p>Selected students are approved for outpass</p><hr/>");
            RequestDispatcher rs = request.getRequestDispatcher("GetValues.jsp");
                        rs.include(request, response);
                        con.close();
            
          
           
    
           
             
            
        }catch(Exception e)
        {
            out.print(e);
        }
        
        
    }

   
}
