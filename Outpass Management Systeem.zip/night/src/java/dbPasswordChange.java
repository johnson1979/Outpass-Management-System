import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class dbPasswordChange extends HttpServlet{
 
    
    protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
       
        String password = request.getParameter("psw");
       
        String cpassword = request.getParameter("cpsw");
     
       HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");
        
               
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
            PreparedStatement ps = con.prepareStatement("update registration set password=('"+password+"') where id='"+id+"'");
           
    
           
             
            int i = ps.executeUpdate();
            if(i>0)
            {
                
                 RequestDispatcher rs = request.getRequestDispatcher("updatePass.html");
                rs.include(request, response);
            }
            else{
                RequestDispatcher rs = request.getRequestDispatcher("changePassword.html");
                rs.include(request, response);
            }
                    
        }
        catch(Exception se)
        {
           out.print("unable to connect to database");
        }
       
    }    
   
            
}