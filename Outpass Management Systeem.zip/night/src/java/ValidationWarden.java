import java.sql.*;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;


public class ValidationWarden
{
   
    public static boolean checkUser(String id,String mail)
    {
            HttpServletResponse response;
            
        
        boolean st = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
            PreparedStatement ps = con.prepareStatement("select * from warden_info where  id=? and mail=?");
            
            ps.setString(1,id);
            ps.setString(2, mail);
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
}