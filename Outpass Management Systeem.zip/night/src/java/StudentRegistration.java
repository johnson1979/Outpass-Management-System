/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author johnson
 */
public class StudentRegistration extends HttpServlet {

   
   

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String dob = request.getParameter("dob");
        String branch = request.getParameter("branch");
        String year  = request.getParameter("year");
        String email = request.getParameter("email");
        String  password= request.getParameter("password");
     
        PreparedStatement ps;
         Connection con;
         
        if(!Validate.checkId(id))
        {
    try{
               
                Class.forName("com.mysql.jdbc.Driver");
               
                  
               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
                
                   
               ps = con.prepareStatement("insert into registration values(?,?,?,?,?,?,?)");
                
                ps.setString(1,id);
                
                ps.setString(2,name);
               
                ps.setString(3,dob);
                 
                ps.setString(4,branch);
                ps.setString(5,year);
                ps.setString(6,email);
                ps.setString(7,password);
                
                int i = ps.executeUpdate();
                
               
                  if(i>0)
                    {
                       RequestDispatcher rs = request.getRequestDispatcher("submission_success_student.html");
                        rs.include(request, response);
                        con.close();
                     }
        }
                        
      catch(Exception e)
                            {
                             out.println(e);
                             }
       
    }
        else if(id==null )
        {
            if(id=="")
            {
            out.print("please enter the id/name first");
             RequestDispatcher rs = request.getRequestDispatcher("student_register.html");
                        rs.include(request, response);  
            }
        }
        else{
            out.print("you are already registered with the id "+id);
             RequestDispatcher rs = request.getRequestDispatcher("student_register.html");
                        rs.include(request, response);
                        
        }
}   }     
            


       

