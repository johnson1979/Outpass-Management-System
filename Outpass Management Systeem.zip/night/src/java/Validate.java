import java.sql.*;
public class Validate
{
    public static boolean checkId(String id)
    {
        boolean st = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
            PreparedStatement ps = con.prepareStatement("select * from registration where  id=?");
            ps.setString(1,id);
            
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
     public static boolean checkUser(String id,String pass)
    {
        boolean st = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
            PreparedStatement ps = con.prepareStatement("select * from registration where  id=? and  password=?");
            ps.setString(1,id);
            ps.setString(2,pass);
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
}