package demo;





import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author johnson
 */
public class CheckWarden {
   
   static String branch="";
   
    
    public static void checkBranch(String id)
    {
            HttpServletResponse response ;
            HttpServletRequest request;
            
            
        
        boolean st = false;
        try
        {
            
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
            PreparedStatement ps = con.prepareStatement("select * from warden_info where  id=?");
            
            ps.setString(1,id);
            
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                    
                
                    String branch=rs.getString("branch");
                    CheckWarden c=new CheckWarden();
                    
                            
                    c.CheckWarden(branch);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
     public  void CheckWarden(String branch)
    {
        this.branch=branch;
        
        
        
        
    }
    public static String getBranch()
    {
        return branch;
        
    }
    
    
}