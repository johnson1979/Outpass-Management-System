package demo;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.http.HttpServletResponse;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author johnson
 */
public class Check {
    
    public static boolean checkId(String id)
    {
            HttpServletResponse response;
            
        
        boolean st = false;
        checkStudent.checkBranch(id);
        String branch=checkStudent.getBranch();
        PreparedStatement ps=null;
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
             if(branch.equals("cse")||branch.equals("CSE"))
          {
            ps = con.prepareStatement("select * from cse where  id=?");
          }
               else if(branch.equals("ece")||branch.equals("ECE"))
          {
             ps = con.prepareStatement("select * from ece where  id=?");
          }
                  else if(branch.equals("mech")||branch.equals("MECH"))
          {
            ps = con.prepareStatement("select * from mech where  id=?");
          }
            
            ps.setString(1,id);
            
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
    
}
