import java.sql.*;
public class cse
{
    public static boolean checkId(String id)
    {
        boolean st = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/warden","root","");
            PreparedStatement ps = con.prepareStatement("select * from cse where  id=?");
            ps.setString(1,id);
            
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
}